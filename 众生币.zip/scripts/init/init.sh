#!/bin/bash

# 安装 Go 环境
install_golang() {
    echo "Installing Go..."
    
    # 下载并安装 Go
    wget https://golang.google.cn/dl/go1.23.linux-amd64.tar.gz
    rm -rf /usr/local/go
    tar -C /usr/local -xzf go1.23.linux-amd64.tar.gz
    rm go1.23.linux-amd64.tar.gz

    # 设置环境变量
    echo 'export PATH=$PATH:/usr/local/go/bin' >> /etc/profile
    echo 'export GOPATH=$HOME/go' >> /etc/profile
    echo 'export GOBIN=$GOPATH/bin' >> /etc/profile
    echo 'export GO111MODULE=on' >> /etc/profile
    echo 'export GOPROXY=https://mirrors.aliyun.com/goproxy/,direct' >> /etc/profile
    echo 'export GOSUMDB=off' >> /etc/profile
    
    # 使环境变量生效
    source /etc/profile
    
    # 验证安装
    go version
}

# 安装其他必要工具
install_tools() {
    echo "Installing required tools..."
    
    # 安装基础工具
    yum install -y wget git make gcc

    # 安装 protoc
    PROTOC_VERSION="3.19.4"
    wget https://github.com/protocolbuffers/protobuf/releases/download/v${PROTOC_VERSION}/protoc-${PROTOC_VERSION}-linux-x86_64.zip
    unzip protoc-${PROTOC_VERSION}-linux-x86_64.zip -d /usr/local
    rm protoc-${PROTOC_VERSION}-linux-x86_64.zip
}

# 设置环境
set_environment() {
    local env=${1:-development}
    echo "Setting up ${env} environment..."
    
    # 加载对应的环境变量文件
    if [ -f ".env.${env}" ]; then
        export $(cat .env.${env} | grep -v '^#' | xargs)
        cp .env.${env} .env
    else
        echo "Environment file .env.${env} not found!"
        exit 1
    fi
}

# 初始化环境
init_environment() {
    # 创建必要的目录
    mkdir -p /var/log/gfc
    mkdir -p /var/lib/gfc
    mkdir -p /etc/gfc/ssl

    # 设置权限
    chown -R www:www /var/log/gfc
    chown -R www:www /var/lib/gfc
}

# 初始化数据库
init_database() {
    # 运行数据库迁移
    migrate -path db/migrations -database "${DB_URL}" up

    # 创建初始用户和角色
    psql -h ${DB_HOST} -U ${DB_USER} -d ${DB_NAME} -f scripts/db/init.sql
}

# 初始化证书
init_certificates() {
    # 生成SSL证书
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout /etc/gfc/ssl/server.key \
        -out /etc/gfc/ssl/server.crt
}

# 安装 protoc
install_protoc() {
    echo "Installing protoc..."
    
    # 安装依赖
    yum install -y unzip curl

    # 下载 protoc
    PROTOC_VERSION="3.19.4"
    PROTOC_ZIP="protoc-${PROTOC_VERSION}-linux-x86_64.zip"
    curl -OL "https://github.com/protocolbuffers/protobuf/releases/download/v${PROTOC_VERSION}/${PROTOC_ZIP}"
    
    # 解压到 /usr/local
    unzip -o $PROTOC_ZIP -d /usr/local bin/protoc
    unzip -o $PROTOC_ZIP -d /usr/local 'include/*'
    
    # 设置权限
    chmod +x /usr/local/bin/protoc
    
    # 清理下载文件
    rm -f $PROTOC_ZIP

    # 安装 Go protoc 插件
    go install google.golang.org/protobuf/cmd/protoc-gen-go@latest
    go install google.golang.org/grpc/cmd/protoc-gen-go-grpc@latest

    # 验证安装
    protoc --version
}

# 主函数
main() {
    local env=${1:-development}
    
    # 安装必要的环境和工具
    install_golang
    install_tools
    install_protoc
    
    # 设置环境和初始化
    set_environment $env
    init_environment
    init_database
    init_certificates
    
    echo "Initialization completed successfully!"
}

main "$@"