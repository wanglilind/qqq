package main

import (
	"context"
	"log"
	"net"
	"os"
	"os/signal"
	"syscall"

	"github.com/wanglilind/qqq/internal/monitor/service"
	"github.com/wanglilind/qqq/pkg/config"
	"github.com/wanglilind/qqq/pkg/logger"
	"google.golang.org/grpc"
)

func main() {
	// 初始化配�?
	cfg, err := config.Load("monitor-service")
	if err != nil {
		log.Fatalf("Failed to load config: %v", err)
	}

	// 初始化日�?
	logger := logger.NewLogger(cfg.LogLevel)
	defer logger.Sync()

	// 创建监控服务实例
	monitorService := service.NewMonitorService(cfg)

	// 启动指标收集
	if err := monitorService.StartMetricsCollection(); err != nil {
		logger.Fatalf("Failed to start metrics collection: %v", err)
	}

	// 创建gRPC服务�?
	grpcServer := grpc.NewServer(
		grpc.UnaryInterceptor(logger.GrpcInterceptor()),
	)

	// 注册服务
	service.RegisterMonitorServiceServer(grpcServer, monitorService)

	// 启动gRPC服务�?
	listener, err := net.Listen("tcp", cfg.GrpcAddress)
	if err != nil {
		logger.Fatalf("Failed to listen: %v", err)
	}

	// 优雅关闭
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	go func() {
		sigCh := make(chan os.Signal, 1)
		signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
		<-sigCh
		logger.Info("Shutting down monitor service...")
		monitorService.StopMetricsCollection()
		grpcServer.GracefulStop()
		cancel()
	}()

	// 启动服务
	logger.Infof("Starting monitor service on %s", cfg.GrpcAddress)
	if err := grpcServer.Serve(listener); err != nil {
		logger.Fatalf("Failed to serve: %v", err)
	}
} 
