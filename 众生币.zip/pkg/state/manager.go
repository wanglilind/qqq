package state

import (
	"context"
	"sync"
	"time"

	"github.com/wanglilind/qqq/pkg/blockchain"
	"github.com/wanglilind/qqq/pkg/database"
)

type StateManager struct {
	db          *database.PostgresDB
	cache       map[string]interface{}
	mu          sync.RWMutex
	subscribers map[string][]chan StateUpdate
	ctx         context.Context
	cancel      context.CancelFunc
}

type StateUpdate struct {
	Type      string
	Key       string
	Value     interface{}
	BlockHash string
	Timestamp time.Time
}

func NewStateManager(db *database.PostgresDB) *StateManager {
	ctx, cancel := context.WithCancel(context.Background())
	return &StateManager{
		db:          db,
		cache:       make(map[string]interface{}),
		subscribers: make(map[string][]chan StateUpdate),
		ctx:         ctx,
		cancel:      cancel,
	}
}

func (sm *StateManager) ApplyBlock(block *blockchain.Block) error {
	sm.mu.Lock()
	defer sm.mu.Unlock()

	// 开始数据库事务
	tx, err := sm.db.BeginTx(sm.ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback()

	// 应用每个交易
	for _, txn := range block.Body.Transactions {
		if err := sm.applyTransaction(tx, txn); err != nil {
			return err
		}
	}

	// 提交事务
	if err := tx.Commit(); err != nil {
		return err
	}

	// 更新缓存
	sm.updateCache(block)

	// 通知订阅�?
	sm.notifySubscribers(block)

	return nil
}

func (sm *StateManager) GetState(key string) (interface{}, error) {
	sm.mu.RLock()
	if value, exists := sm.cache[key]; exists {
		sm.mu.RUnlock()
		return value, nil
	}
	sm.mu.RUnlock()

	// 从数据库加载
	value, err := sm.loadFromDB(key)
	if err != nil {
		return nil, err
	}

	sm.mu.Lock()
	sm.cache[key] = value
	sm.mu.Unlock()

	return value, nil
}

func (sm *StateManager) Subscribe(stateType string) chan StateUpdate {
	ch := make(chan StateUpdate, 100)
	
	sm.mu.Lock()
	sm.subscribers[stateType] = append(sm.subscribers[stateType], ch)
	sm.mu.Unlock()

	return ch
}

func (sm *StateManager) applyTransaction(tx *database.Tx, transaction blockchain.Transaction) error {
	// 实现具体的交易应用逻辑
	return nil
}

func (sm *StateManager) updateCache(block *blockchain.Block) {
	// 更新内存缓存
}

func (sm *StateManager) notifySubscribers(block *blockchain.Block) {
	update := StateUpdate{
		BlockHash: block.Hash,
		Timestamp: block.Header.Timestamp,
	}

	sm.mu.RLock()
	defer sm.mu.RUnlock()

	for _, subs := range sm.subscribers {
		for _, ch := range subs {
			select {
			case ch <- update:
			default:
				// 如果channel已满，跳�?
			}
		}
	}
}

func (sm *StateManager) loadFromDB(key string) (interface{}, error) {
	// 从数据库加载状�?
	return nil, nil
}

func (sm *StateManager) Close() {
	sm.cancel()
	// 清理资源
} 
