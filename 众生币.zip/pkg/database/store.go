package database

import (
	"context"
	"sync"
	"time"

	"github.com/cockroachdb/cockroach-go/v2/crdb"
	"github.com/syndtr/goleveldb/leveldb"
	"github.com/go-redis/redis/v8"
)

// StoreManager manages different types of storage
type StoreManager struct {
	sqlDB    *crdb.DB          // CockroachDB connection
	levelDB  *leveldb.DB       // LevelDB instance
	redisDB  *redis.Client     // Redis client
	mu       sync.RWMutex
}

// StoreConfig contains configuration options
type StoreConfig struct {
	CockroachURL string
	LevelDBPath  string
	RedisURL     string
}

func NewStoreManager(config *StoreConfig) (*StoreManager, error) {
	sm := &StoreManager{}
	
	// Initialize CockroachDB connection
	sqlDB, err := crdb.Connect(config.CockroachURL)
	if err != nil {
		return nil, err
	}
	sm.sqlDB = sqlDB

	// Initialize LevelDB
	levelDB, err := leveldb.OpenFile(config.LevelDBPath, nil)
	if err != nil {
		return nil, err
	}
	sm.levelDB = levelDB

	// Initialize Redis connection
	redisDB := redis.NewClient(&redis.Options{
		Addr: config.RedisURL,
	})
	sm.redisDB = redisDB

	return sm, nil
}

// ExecSQL executes SQL operations for user data, accounts etc.
func (sm *StoreManager) ExecSQL(ctx context.Context, fn func(*crdb.Tx) error) error {
	return crdb.ExecuteTx(ctx, sm.sqlDB, nil, fn)
}

// PutBlock stores blockchain data
func (sm *StoreManager) PutBlock(key []byte, value []byte) error {
	return sm.levelDB.Put(key, value, nil)
}

func (sm *StoreManager) GetBlock(key []byte) ([]byte, error) {
	return sm.levelDB.Get(key, nil)
}

// SetCache handles hot data caching
func (sm *StoreManager) SetCache(ctx context.Context, key string, value interface{}, ttl time.Duration) error {
	return sm.redisDB.Set(ctx, key, value, ttl).Err()
}

func (sm *StoreManager) GetCache(ctx context.Context, key string) (string, error) {
	return sm.redisDB.Get(ctx, key).Result()
}

// Close closes all connections
func (sm *StoreManager) Close() error {
	sm.mu.Lock()
	defer sm.mu.Unlock()

	if err := sm.sqlDB.Close(); err != nil {
		return err
	}
	if err := sm.levelDB.Close(); err != nil {
		return err
	}
	if err := sm.redisDB.Close(); err != nil {
		return err
	}
	return nil
}
