package database

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v4/pgxpool"
)

type PostgresDB struct {
	pool *pgxpool.Pool
}

func NewPostgresDB(config *Config) (*PostgresDB, error) {
	ctx := context.Background()
	
	// 构建连接字符�?
	connString := fmt.Sprintf(
		"postgres://%s:%s@%s:%d/%s?sslmode=verify-full",
		config.User,
		config.Password,
		config.Host,
		config.Port,
		config.Database,
	)

	// 配置连接�?
	poolConfig, err := pgxpool.ParseConfig(connString)
	if err != nil {
		return nil, fmt.Errorf("unable to parse config: %v", err)
	}

	// 设置连接池参�?
	poolConfig.MaxConns = 100
	poolConfig.MinConns = 10
	poolConfig.MaxConnLifetime = time.Hour
	poolConfig.MaxConnIdleTime = 30 * time.Minute
	poolConfig.HealthCheckPeriod = 1 * time.Minute

	// 创建连接�?
	pool, err := pgxpool.ConnectConfig(ctx, poolConfig)
	if err != nil {
		return nil, fmt.Errorf("unable to create connection pool: %v", err)
	}

	return &PostgresDB{pool: pool}, nil
} 
