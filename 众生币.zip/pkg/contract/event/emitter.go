package event

import (
	"context"
	"sync"
	"time"
)

// 事件定义
type Event struct {
	ContractAddress string
	EventType      string
	Data           map[string]interface{}
	BlockNumber    uint64
	TransactionHash string
	Timestamp      time.Time
}

// 事件过滤�?
type EventFilter struct {
	ContractAddress string
	EventTypes     []string
	FromBlock      uint64
	ToBlock        uint64
}

// 事件发射�?
type EventEmitter struct {
	mu          sync.RWMutex
	subscribers map[string][]chan Event
	events      []Event
	maxEvents   int
}

func NewEventEmitter(maxEvents int) *EventEmitter {
	return &EventEmitter{
		subscribers: make(map[string][]chan Event),
		events:     make([]Event, 0, maxEvents),
		maxEvents:  maxEvents,
	}
}

// 发出事件
func (ee *EventEmitter) Emit(event Event) {
	ee.mu.Lock()
	// 存储事件
	ee.events = append(ee.events, event)
	if len(ee.events) > ee.maxEvents {
		ee.events = ee.events[1:]
	}
	
	// 获取订阅�?
	subscribers := ee.subscribers[event.EventType]
	ee.mu.Unlock()

	// 通知订阅�?
	for _, ch := range subscribers {
		select {
		case ch <- event:
		default:
			// 如果channel已满，跳�?
		}
	}
}

// 订阅事件
func (ee *EventEmitter) Subscribe(ctx context.Context, filter EventFilter) (<-chan Event, error) {
	ch := make(chan Event, 100)
	
	ee.mu.Lock()
	for _, eventType := range filter.EventTypes {
		ee.subscribers[eventType] = append(ee.subscribers[eventType], ch)
	}
	ee.mu.Unlock()

	// 发送历史事�?
	go ee.sendHistoricalEvents(ctx, filter, ch)

	return ch, nil
}

// 发送历史事�?
func (ee *EventEmitter) sendHistoricalEvents(ctx context.Context, filter EventFilter, ch chan Event) {
	ee.mu.RLock()
	defer ee.mu.RUnlock()

	for _, event := range ee.events {
		if ee.matchesFilter(event, filter) {
			select {
			case <-ctx.Done():
				return
			case ch <- event:
			}
		}
	}
}

// 检查事件是否匹配过滤器
func (ee *EventEmitter) matchesFilter(event Event, filter EventFilter) bool {
	if filter.ContractAddress != "" && event.ContractAddress != filter.ContractAddress {
		return false
	}

	if filter.FromBlock > event.BlockNumber || (filter.ToBlock != 0 && filter.ToBlock < event.BlockNumber) {
		return false
	}

	if len(filter.EventTypes) > 0 {
		matched := false
		for _, t := range filter.EventTypes {
			if t == event.EventType {
				matched = true
				break
			}
		}
		if !matched {
			return false
		}
	}

	return true
}

// 取消订阅
func (ee *EventEmitter) Unsubscribe(eventType string, ch chan Event) {
	ee.mu.Lock()
	defer ee.mu.Unlock()

	subscribers := ee.subscribers[eventType]
	for i, subscriber := range subscribers {
		if subscriber == ch {
			ee.subscribers[eventType] = append(subscribers[:i], subscribers[i+1:]...)
			break
		}
	}
} 
