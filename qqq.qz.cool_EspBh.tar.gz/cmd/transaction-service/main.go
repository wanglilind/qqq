package main

import (
	"context"
	"log"
	"net"
	"os"
	"os/signal"
	"syscall"

	"github.com/your-org/global-fair-currency/internal/transaction/service"
	"github.com/your-org/global-fair-currency/pkg/config"
	"github.com/your-org/global-fair-currency/pkg/logger"
	"google.golang.org/grpc"
)

func main() {
	// 初始化配置
	cfg, err := config.Load("transaction-service")
	if err != nil {
		log.Fatalf("Failed to load config: %v", err)
	}

	// 初始化日志
	logger := logger.NewLogger(cfg.LogLevel)
	defer logger.Sync()

	// 创建交易服务实例
	transactionService := service.NewTransactionService(cfg)

	// 创建gRPC服务器
	grpcServer := grpc.NewServer(
		grpc.UnaryInterceptor(logger.GrpcInterceptor()),
	)

	// 注册服务
	service.RegisterTransactionServiceServer(grpcServer, transactionService)

	// 启动gRPC服务器
	listener, err := net.Listen("tcp", cfg.GrpcAddress)
	if err != nil {
		logger.Fatalf("Failed to listen: %v", err)
	}

	// 优雅关闭
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	go func() {
		sigCh := make(chan os.Signal, 1)
		signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
		<-sigCh
		logger.Info("Shutting down gRPC server...")
		grpcServer.GracefulStop()
		cancel()
	}()

	// 启动服务
	logger.Infof("Starting transaction service on %s", cfg.GrpcAddress)
	if err := grpcServer.Serve(listener); err != nil {
		logger.Fatalf("Failed to serve: %v", err)
	}
} 