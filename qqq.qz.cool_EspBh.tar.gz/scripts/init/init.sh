#!/bin/bash

# 初始化环境
init_environment() {
    # 创建必要的目录
    mkdir -p /var/log/gfc
    mkdir -p /var/lib/gfc
    mkdir -p /etc/gfc/ssl

    # 设置权限
    chown -R gfc:gfc /var/log/gfc
    chown -R gfc:gfc /var/lib/gfc
}

# 初始化数据库
init_database() {
    # 运行数据库迁移
    migrate -path db/migrations -database "${DB_URL}" up

    # 创建初始用户和角色
    psql -h ${DB_HOST} -U ${DB_USER} -d ${DB_NAME} -f scripts/db/init.sql
}

# 初始化证书
init_certificates() {
    # 生成SSL证书
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout /etc/gfc/ssl/server.key \
        -out /etc/gfc/ssl/server.crt
}

# 主函数
main() {
    init_environment
    init_database
    init_certificates
}

main 