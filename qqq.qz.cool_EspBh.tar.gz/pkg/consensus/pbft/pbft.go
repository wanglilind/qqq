package pbft

import (
	"context"
	"sync"
	"time"

	"github.com/your-org/global-fair-currency/pkg/blockchain"
)

type State int

const (
	PrePrepare State = iota
	Prepare
	Commit
	Finalize
)

type ConsensusMessage struct {
	Type      State
	BlockHash string
	NodeID    string
	Signature []byte
}

type PBFT struct {
	mu              sync.RWMutex
	nodeID          string
	validators      map[string]bool
	currentState    State
	prepareVotes    map[string]map[string]bool  // blockHash -> nodeID -> vote
	commitVotes     map[string]map[string]bool
	pendingBlocks   map[string]*blockchain.Block
	config          *Config
	msgChan         chan ConsensusMessage
}

func NewPBFT(nodeID string, config *Config) *PBFT {
	return &PBFT{
		nodeID:        nodeID,
		validators:    make(map[string]bool),
		prepareVotes:  make(map[string]map[string]bool),
		commitVotes:   make(map[string]map[string]bool),
		pendingBlocks: make(map[string]*blockchain.Block),
		config:        config,
		msgChan:      make(chan ConsensusMessage, 1000),
	}
}

func (p *PBFT) Start(ctx context.Context) error {
	go p.processMessages(ctx)
	return nil
}

func (p *PBFT) ProposeBlock(block *blockchain.Block) error {
	p.mu.Lock()
	defer p.mu.Unlock()

	blockHash := block.CalculateHash()
	p.pendingBlocks[blockHash] = block
	
	// 广播PrePrepare消息
	msg := ConsensusMessage{
		Type:      PrePrepare,
		BlockHash: blockHash,
		NodeID:    p.nodeID,
	}
	
	return p.broadcast(msg)
}

func (p *PBFT) processMessages(ctx context.Context) {
	for {
		select {
		case <-ctx.Done():
			return
		case msg := <-p.msgChan:
			p.handleMessage(msg)
		}
	}
}

func (p *PBFT) handleMessage(msg ConsensusMessage) {
	p.mu.Lock()
	defer p.mu.Unlock()

	switch msg.Type {
	case PrePrepare:
		p.handlePrePrepare(msg)
	case Prepare:
		p.handlePrepare(msg)
	case Commit:
		p.handleCommit(msg)
	}
}

func (p *PBFT) handlePrePrepare(msg ConsensusMessage) {
	// 验证消息
	if !p.validateMessage(msg) {
		return
	}

	// 初始化投票记录
	if _, exists := p.prepareVotes[msg.BlockHash]; !exists {
		p.prepareVotes[msg.BlockHash] = make(map[string]bool)
	}

	// 发送Prepare消息
	prepareMsg := ConsensusMessage{
		Type:      Prepare,
		BlockHash: msg.BlockHash,
		NodeID:    p.nodeID,
	}
	p.broadcast(prepareMsg)
}

func (p *PBFT) handlePrepare(msg ConsensusMessage) {
	// 记录Prepare投票
	p.prepareVotes[msg.BlockHash][msg.NodeID] = true

	// 检查是否达到准备阈值
	if p.checkPrepareQuorum(msg.BlockHash) {
		commitMsg := ConsensusMessage{
			Type:      Commit,
			BlockHash: msg.BlockHash,
			NodeID:    p.nodeID,
		}
		p.broadcast(commitMsg)
	}
}

func (p *PBFT) handleCommit(msg ConsensusMessage) {
	// 记录Commit投票
	if _, exists := p.commitVotes[msg.BlockHash]; !exists {
		p.commitVotes[msg.BlockHash] = make(map[string]bool)
	}
	p.commitVotes[msg.BlockHash][msg.NodeID] = true

	// 检查是否达到提交阈值
	if p.checkCommitQuorum(msg.BlockHash) {
		p.finalizeBlock(msg.BlockHash)
	}
}

func (p *PBFT) checkPrepareQuorum(blockHash string) bool {
	return len(p.prepareVotes[blockHash]) >= p.getQuorumSize()
}

func (p *PBFT) checkCommitQuorum(blockHash string) bool {
	return len(p.commitVotes[blockHash]) >= p.getQuorumSize()
}

func (p *PBFT) getQuorumSize() int {
	return (len(p.validators) * 2 / 3) + 1
}

func (p *PBFT) validateMessage(msg ConsensusMessage) bool {
	// 验证消息签名和发送者身份
	return true
}

func (p *PBFT) broadcast(msg ConsensusMessage) error {
	// 广播消息到所有验证节点
	return nil
}

func (p *PBFT) finalizeBlock(blockHash string) {
	// 最终确认区块
	block := p.pendingBlocks[blockHash]
	// 执行区块并更新状态
	delete(p.pendingBlocks, blockHash)
	delete(p.prepareVotes, blockHash)
	delete(p.commitVotes, blockHash)
} 