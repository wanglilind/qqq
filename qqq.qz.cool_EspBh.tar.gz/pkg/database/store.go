package database

import (
	"context"
	"sync"
	"time"

	"github.com/cockroachdb/cockroach-go/v2/crdb"
	"github.com/syndtr/goleveldb/leveldb"
	"github.com/go-redis/redis/v8"
)

// 数据存储管理器
type StoreManager struct {
	sqlDB    *crdb.DB          // CockroachDB连接
	levelDB  *leveldb.DB       // LevelDB实例
	redisDB  *redis.Client     // Redis客户端
	mu       sync.RWMutex
}

// 配置选项
type StoreConfig struct {
	CockroachURL string
	LevelDBPath  string
	RedisURL     string
}

func NewStoreManager(config *StoreConfig) (*StoreManager, error) {
	sm := &StoreManager{}
	
	// 初始化CockroachDB连接
	sqlDB, err := crdb.Connect(config.CockroachURL)
	if err != nil {
		return nil, err
	}
	sm.sqlDB = sqlDB

	// 初始化LevelDB
	levelDB, err := leveldb.OpenFile(config.LevelDBPath, nil)
	if err != nil {
		return nil, err
	}
	sm.levelDB = levelDB

	// 初始化Redis连接
	redisDB := redis.NewClient(&redis.Options{
		Addr: config.RedisURL,
	})
	sm.redisDB = redisDB

	return sm, nil
}

// SQL操作 - 用于用户数据、账户等
func (sm *StoreManager) ExecSQL(ctx context.Context, fn func(*crdb.Tx) error) error {
	return crdb.ExecuteTx(ctx, sm.sqlDB, nil, fn)
}

// 区块存储 - 用于区块链数据
func (sm *StoreManager) PutBlock(key []byte, value []byte) error {
	return sm.levelDB.Put(key, value, nil)
}

func (sm *StoreManager) GetBlock(key []byte) ([]byte, error) {
	return sm.levelDB.Get(key, nil)
}

// 缓存操作 - 用于热点数据
func (sm *StoreManager) SetCache(ctx context.Context, key string, value interface{}, ttl time.Duration) error {
	return sm.redisDB.Set(ctx, key, value, ttl).Err()
}

func (sm *StoreManager) GetCache(ctx context.Context, key string) (string, error) {
	return sm.redisDB.Get(ctx, key).Result()
}

// 关闭所有连接
func (sm *StoreManager) Close() error {
	sm.mu.Lock()
	defer sm.mu.Unlock()

	if err := sm.sqlDB.Close(); err != nil {
		return err
	}
	if err := sm.levelDB.Close(); err != nil {
		return err
	}
	if err := sm.redisDB.Close(); err != nil {
		return err
	}
	return nil
} 