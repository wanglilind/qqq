package dao

import (
	"context"
	"time"

	"github.com/your-org/global-fair-currency/pkg/database"
)

// DAO接口定义
type DAO interface {
	IdentityDAO
	AccountDAO
	TransactionDAO
	SystemDAO
}

// 身份相关DAO接口
type IdentityDAO interface {
	CreateIdentity(ctx context.Context, identity *Identity) error
	GetIdentity(ctx context.Context, id string) (*Identity, error)
	UpdateIdentity(ctx context.Context, identity *Identity) error
	VerifyIdentity(ctx context.Context, id string, biometricData []byte) (bool, error)
	ListIdentities(ctx context.Context, filter *IdentityFilter) ([]*Identity, error)
}

// 账户相关DAO接口
type AccountDAO interface {
	CreateAccount(ctx context.Context, account *Account) error
	GetAccount(ctx context.Context, id string) (*Account, error)
	UpdateBalance(ctx context.Context, id string, amount float64) error
	GetAccountHistory(ctx context.Context, id string, startTime, endTime time.Time) ([]*AccountActivity, error)
	ListAccounts(ctx context.Context, filter *AccountFilter) ([]*Account, error)
}

// 交易相关DAO接口
type TransactionDAO interface {
	CreateTransaction(ctx context.Context, tx *Transaction) error
	GetTransaction(ctx context.Context, id string) (*Transaction, error)
	UpdateTransactionStatus(ctx context.Context, id string, status string) error
	ListTransactions(ctx context.Context, filter *TransactionFilter) ([]*Transaction, error)
	GetTransactionStats(ctx context.Context, accountId string) (*TransactionStatistics, error)
}

// 系统参数相关DAO接口
type SystemDAO interface {
	GetParameter(ctx context.Context, key string) (string, error)
	SetParameter(ctx context.Context, key string, value string) error
	ListParameters(ctx context.Context) (map[string]string, error)
}

// DAO实现
type daoImpl struct {
	store *database.StoreManager
}

func NewDAO(store *database.StoreManager) DAO {
	return &daoImpl{
		store: store,
	}
}

// 身份DAO实现
func (d *daoImpl) CreateIdentity(ctx context.Context, identity *Identity) error {
	return d.store.ExecSQL(ctx, func(tx *database.Tx) error {
		query := `
			INSERT INTO identities (
				id, user_id, biometric_hash, national_id, country_code, 
				birth_date, status, verification_count, metadata
			) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
		`
		_, err := tx.Exec(ctx, query,
			identity.ID, identity.UserID, identity.BiometricHash,
			identity.NationalID, identity.CountryCode, identity.BirthDate,
			identity.Status, identity.VerificationCount, identity.Metadata,
		)
		return err
	})
}

// 账户DAO实现
func (d *daoImpl) UpdateBalance(ctx context.Context, id string, amount float64) error {
	return d.store.ExecSQL(ctx, func(tx *database.Tx) error {
		// 开始事务
		query := `
			UPDATE currency_accounts 
			SET current_balance = current_balance + $1,
				last_decay_date = CURRENT_TIMESTAMP
			WHERE id = $2
		`
		result, err := tx.Exec(ctx, query, amount, id)
		if err != nil {
			return err
		}

		// 记录账户活动
		activityQuery := `
			INSERT INTO account_activities (
				id, account_id, activity_type, amount, 
				balance_before, balance_after, timestamp
			) VALUES ($1, $2, $3, $4, $5, $6, CURRENT_TIMESTAMP)
		`
		_, err = tx.Exec(ctx, activityQuery,
			NewUUID(), id, "BALANCE_UPDATE", amount,
			0, 0, // 这里需要获取实际的余额变化
		)
		return err
	})
}

// 交易DAO实现
func (d *daoImpl) CreateTransaction(ctx context.Context, tx *Transaction) error {
	return d.store.ExecSQL(ctx, func(dbTx *database.Tx) error {
		query := `
			INSERT INTO transactions (
				id, sender_id, recipient_id, amount, 
				transaction_type, status, signature
			) VALUES ($1, $2, $3, $4, $5, $6, $7)
		`
		_, err := dbTx.Exec(ctx, query,
			tx.ID, tx.SenderID, tx.RecipientID,
			tx.Amount, tx.Type, tx.Status, tx.Signature,
		)
		if err != nil {
			return err
		}

		// 更新统计数据
		statsQuery := `
			INSERT INTO transaction_statistics (
				id, account_id, period_start, period_end,
				total_transactions, total_amount
			) VALUES ($1, $2, $3, $4, $5, $6)
			ON CONFLICT (account_id, period_start) DO UPDATE
			SET total_transactions = transaction_statistics.total_transactions + 1,
				total_amount = transaction_statistics.total_amount + EXCLUDED.total_amount
		`
		_, err = dbTx.Exec(ctx, statsQuery,
			NewUUID(), tx.SenderID,
			time.Now().Truncate(24*time.Hour),
			time.Now().Truncate(24*time.Hour).Add(24*time.Hour),
			1, tx.Amount,
		)
		return err
	})
}

// 系统参数DAO实现
func (d *daoImpl) GetParameter(ctx context.Context, key string) (string, error) {
	var value string
	err := d.store.ExecSQL(ctx, func(tx *database.Tx) error {
		return tx.QueryRow(ctx,
			"SELECT parameter_value FROM system_parameters WHERE parameter_key = $1",
			key,
		).Scan(&value)
	})
	return value, err
} 