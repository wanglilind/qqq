package security

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	
	"github.com/your-org/global-fair-currency/pkg/contract"
)

type SecurityChecker struct {
	knownVulnerabilities map[string]string
	maxCodeSize         int
	maxStackDepth       int
	bannedOpcodes      map[byte]bool
}

func NewSecurityChecker() *SecurityChecker {
	return &SecurityChecker{
		knownVulnerabilities: make(map[string]string),
		maxCodeSize:         1024 * 1024, // 1MB
		maxStackDepth:       1000,
		bannedOpcodes:      map[byte]bool{
			0xF4: true, // SELFDESTRUCT
			0xFF: true, // DELEGATECALL
		},
	}
}

// 检查合约代码安全性
func (sc *SecurityChecker) CheckContract(code []byte) ([]SecurityIssue, error) {
	var issues []SecurityIssue

	// 检查代码大小
	if len(code) > sc.maxCodeSize {
		issues = append(issues, SecurityIssue{
			Type:        "CODE_SIZE",
			Severity:    "HIGH",
			Description: "Contract code size exceeds maximum limit",
		})
	}

	// 检查已知漏洞
	codeHash := sha256.Sum256(code)
	if vulnerability, exists := sc.knownVulnerabilities[hex.EncodeToString(codeHash[:])]; exists {
		issues = append(issues, SecurityIssue{
			Type:        "KNOWN_VULNERABILITY",
			Severity:    "CRITICAL",
			Description: vulnerability,
		})
	}

	// 检查危险操作码
	issues = append(issues, sc.checkOpcodes(code)...)

	// 检查重入漏洞
	issues = append(issues, sc.checkReentrancy(code)...)

	// 检查整数溢出
	issues = append(issues, sc.checkIntegerOverflow(code)...)

	return issues, nil
}

// 检查操作码安全性
func (sc *SecurityChecker) checkOpcodes(code []byte) []SecurityIssue {
	var issues []SecurityIssue
	
	for i := 0; i < len(code); i++ {
		if sc.bannedOpcodes[code[i]] {
			issues = append(issues, SecurityIssue{
				Type:        "BANNED_OPCODE",
				Severity:    "HIGH",
				Description: "Contract contains banned opcode",
				Location:    i,
			})
		}
	}
	
	return issues
}

// 检查重入漏洞
func (sc *SecurityChecker) checkReentrancy(code []byte) []SecurityIssue {
	var issues []SecurityIssue
	
	// 检查状态变更在外部调用之后
	if bytes.Contains(code, []byte{0xf1, 0x15}) { // CALL followed by SSTORE
		issues = append(issues, SecurityIssue{
			Type:        "REENTRANCY",
			Severity:    "HIGH",
			Description: "Potential reentrancy vulnerability detected",
		})
	}
	
	return issues
}

// 检查整数溢出
func (sc *SecurityChecker) checkIntegerOverflow(code []byte) []SecurityIssue {
	var issues []SecurityIssue
	
	// 检查是否有未检查的算术操作
	if bytes.Contains(code, []byte{0x01}) && !bytes.Contains(code, []byte{0x10}) { // ADD without overflow check
		issues = append(issues, SecurityIssue{
			Type:        "INTEGER_OVERFLOW",
			Severity:    "MEDIUM",
			Description: "Potential integer overflow detected",
		})
	}
	
	return issues
}

type SecurityIssue struct {
	Type        string
	Severity    string
	Description string
	Location    int
} 