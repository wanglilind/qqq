package stdlib

import (
	"time"
	"math/big"
	
	"github.com/your-org/global-fair-currency/pkg/contract"
)

// 标准库合约接口
type StandardContract interface {
	Initialize() error
	GetBalance() (*big.Int, error)
	Transfer(to string, amount *big.Int) error
	GetOwner() string
	IsExpired() bool
}

// 基础合约实现
type BaseContract struct {
	contract.Contract
	decayRate     *big.Int
	creationTime  time.Time
	maxLifespan   time.Duration
}

func NewBaseContract() *BaseContract {
	return &BaseContract{
		decayRate:    big.NewInt(120), // 120年衰减
		maxLifespan:  120 * 365 * 24 * time.Hour,
		creationTime: time.Now(),
	}
}

// 计算当前余额（考虑衰减）
func (bc *BaseContract) GetBalance() (*big.Int, error) {
	currentBalance := new(big.Int).Set(bc.State["balance"].(*big.Int))
	elapsedTime := time.Since(bc.creationTime)
	
	// 计算衰减
	if elapsedTime > 0 {
		decayFactor := new(big.Int).Mul(
			big.NewInt(int64(elapsedTime.Hours())/24/365),
			bc.decayRate,
		)
		currentBalance.Sub(currentBalance, decayFactor)
		if currentBalance.Sign() < 0 {
			currentBalance = big.NewInt(0)
		}
	}
	
	return currentBalance, nil
}

// 转账实现
func (bc *BaseContract) Transfer(to string, amount *big.Int) error {
	balance, err := bc.GetBalance()
	if err != nil {
		return err
	}
	
	if balance.Cmp(amount) < 0 {
		return ErrInsufficientBalance
	}
	
	// 执行转账
	bc.State["balance"].(*big.Int).Sub(bc.State["balance"].(*big.Int), amount)
	return nil
}

// 检查合约是否过期
func (bc *BaseContract) IsExpired() bool {
	return time.Since(bc.creationTime) > bc.maxLifespan
} 