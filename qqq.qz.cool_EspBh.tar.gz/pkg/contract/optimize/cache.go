package optimize

import (
	"sync"
	"time"

	"github.com/your-org/global-fair-currency/pkg/contract"
)

// 合约缓存管理器
type ContractCache struct {
	mu            sync.RWMutex
	codeCache     map[string][]byte
	stateCache    map[string]map[string]interface{}
	resultCache   map[string]CachedResult
	maxSize       int
	expiration    time.Duration
}

type CachedResult struct {
	Result     interface{}
	Timestamp  time.Time
	AccessCount int
}

func NewContractCache(maxSize int, expiration time.Duration) *ContractCache {
	return &ContractCache{
		codeCache:   make(map[string][]byte),
		stateCache:  make(map[string]map[string]interface{}),
		resultCache: make(map[string]CachedResult),
		maxSize:     maxSize,
		expiration:  expiration,
	}
}

// 缓存合约代码
func (cc *ContractCache) CacheCode(address string, code []byte) {
	cc.mu.Lock()
	defer cc.mu.Unlock()

	if len(cc.codeCache) >= cc.maxSize {
		cc.evictOldest()
	}

	cc.codeCache[address] = code
}

// 缓存合约状态
func (cc *ContractCache) CacheState(address string, state map[string]interface{}) {
	cc.mu.Lock()
	defer cc.mu.Unlock()

	cc.stateCache[address] = state
}

// 缓存执行结果
func (cc *ContractCache) CacheResult(key string, result interface{}) {
	cc.mu.Lock()
	defer cc.mu.Unlock()

	if len(cc.resultCache) >= cc.maxSize {
		cc.evictLeastUsed()
	}

	cc.resultCache[key] = CachedResult{
		Result:     result,
		Timestamp:  time.Now(),
		AccessCount: 0,
	}
}

// 获取缓存结果
func (cc *ContractCache) GetResult(key string) (interface{}, bool) {
	cc.mu.RLock()
	defer cc.mu.RUnlock()

	if cached, exists := cc.resultCache[key]; exists {
		if time.Since(cached.Timestamp) > cc.expiration {
			delete(cc.resultCache, key)
			return nil, false
		}
		
		cached.AccessCount++
		cc.resultCache[key] = cached
		return cached.Result, true
	}
	return nil, false
}

// 清理过期缓存
func (cc *ContractCache) CleanupExpired() {
	cc.mu.Lock()
	defer cc.mu.Unlock()

	now := time.Now()
	for key, cached := range cc.resultCache {
		if now.Sub(cached.Timestamp) > cc.expiration {
			delete(cc.resultCache, key)
		}
	}
}

// 驱逐最旧的缓存
func (cc *ContractCache) evictOldest() {
	var oldestKey string
	var oldestTime time.Time

	for key, cached := range cc.resultCache {
		if oldestKey == "" || cached.Timestamp.Before(oldestTime) {
			oldestKey = key
			oldestTime = cached.Timestamp
		}
	}

	if oldestKey != "" {
		delete(cc.resultCache, oldestKey)
	}
}

// 驱逐最少使用的缓存
func (cc *ContractCache) evictLeastUsed() {
	var leastUsedKey string
	var leastCount int

	for key, cached := range cc.resultCache {
		if leastUsedKey == "" || cached.AccessCount < leastCount {
			leastUsedKey = key
			leastCount = cached.AccessCount
		}
	}

	if leastUsedKey != "" {
		delete(cc.resultCache, leastUsedKey)
	}
} 