package crypto

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/x509"
	"encoding/pem"
	"errors"
)

type Signer struct {
	privateKey *ecdsa.PrivateKey
	publicKey  *ecdsa.PublicKey
}

func NewSigner() (*Signer, error) {
	// 生成ECDSA密钥对
	privateKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return nil, err
	}

	return &Signer{
		privateKey: privateKey,
		publicKey:  &privateKey.PublicKey,
	}, nil
}

// Sign 对数据进行签名
func (s *Signer) Sign(data []byte) ([]byte, error) {
	// 计算数据哈希
	hasher := NewHasher(SHA256)
	hash := hasher.Hash(data)

	// 签名
	r, ss, err := ecdsa.Sign(rand.Reader, s.privateKey, []byte(hash))
	if err != nil {
		return nil, err
	}

	// 组合签名结果
	signature := append(r.Bytes(), ss.Bytes()...)
	return signature, nil
}

// Verify 验证签名
func (s *Signer) Verify(data []byte, signature []byte) bool {
	// 计算数据哈希
	hasher := NewHasher(SHA256)
	hash := hasher.Hash(data)

	// 解析签名
	r := new(ecdsa.PublicKey)
	ss := new(ecdsa.PublicKey)
	// 这里需要正确分割signature来获取r和s
	
	// 验证签名
	return ecdsa.Verify(s.publicKey, []byte(hash), r.X, ss.X)
}

// ExportPublicKey 导出公钥
func (s *Signer) ExportPublicKey() (string, error) {
	publicKeyBytes, err := x509.MarshalPKIXPublicKey(s.publicKey)
	if err != nil {
		return "", err
	}

	publicKeyPEM := pem.EncodeToMemory(&pem.Block{
		Type:  "PUBLIC KEY",
		Bytes: publicKeyBytes,
	})

	return string(publicKeyPEM), nil
}

// ImportPublicKey 导入公钥
func (s *Signer) ImportPublicKey(publicKeyPEM string) error {
	block, _ := pem.Decode([]byte(publicKeyPEM))
	if block == nil {
		return errors.New("failed to decode PEM block")
	}

	publicKey, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		return err
	}

	ecdsaPublicKey, ok := publicKey.(*ecdsa.PublicKey)
	if !ok {
		return errors.New("not an ECDSA public key")
	}

	s.publicKey = ecdsaPublicKey
	return nil
} 