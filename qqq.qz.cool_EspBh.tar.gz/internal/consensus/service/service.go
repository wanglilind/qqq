package service

import (
	"context"
	"sync"

	"github.com/your-org/global-fair-currency/internal/consensus/node"
	"github.com/your-org/global-fair-currency/internal/consensus/algorithm"
	"github.com/your-org/global-fair-currency/internal/consensus/network"
	"github.com/your-org/global-fair-currency/pkg/config"
)

type ConsensusService struct {
	nodeManager    *node.Manager
	consensusAlgo  *algorithm.Consensus
	networkManager *network.Manager
	config         *config.Config
	mu            sync.RWMutex
	isRunning     bool
}

func NewConsensusService(cfg *config.Config) *ConsensusService {
	return &ConsensusService{
		nodeManager:    node.NewManager(cfg),
		consensusAlgo:  algorithm.NewConsensus(cfg),
		networkManager: network.NewManager(cfg),
		config:        cfg,
	}
}

// StartP2PNetwork 启动P2P网络
func (s *ConsensusService) StartP2PNetwork() error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if s.isRunning {
		return nil
	}

	// 初始化网络
	if err := s.networkManager.Initialize(); err != nil {
		return err
	}

	// 启动节点发现
	if err := s.nodeManager.StartDiscovery(); err != nil {
		return err
	}

	// 启动共识算法
	if err := s.consensusAlgo.Start(); err != nil {
		return err
	}

	s.isRunning = true
	return nil
}

// StopP2PNetwork 停止P2P网络
func (s *ConsensusService) StopP2PNetwork() error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if !s.isRunning {
		return nil
	}

	// 停止共识算法
	s.consensusAlgo.Stop()

	// 停止节点发现
	s.nodeManager.StopDiscovery()

	// 关闭网络连接
	s.networkManager.Shutdown()

	s.isRunning = false
	return nil
}

// ProposeBlock 提议新区块
func (s *ConsensusService) ProposeBlock(ctx context.Context, req *ProposeBlockRequest) (*ProposeBlockResponse, error) {
	// 验证提议者身份
	if err := s.validateProposer(req.ProposerId); err != nil {
		return nil, err
	}

	// 创建区块提议
	block := &Block{
		Transactions: req.Transactions,
		Timestamp:   req.Timestamp,
		ProposerId:  req.ProposerId,
	}

	// 进行共识
	consensus, err := s.consensusAlgo.ProcessBlock(block)
	if err != nil {
		return nil, err
	}

	// 广播区块
	if err := s.networkManager.BroadcastBlock(block); err != nil {
		return nil, err
	}

	return &ProposeBlockResponse{
		BlockId:     block.Id,
		ConsensusId: consensus.Id,
		Status:      "proposed",
	}, nil
}

// GetConsensusStatus 获取共识状态
func (s *ConsensusService) GetConsensusStatus(ctx context.Context, req *GetConsensusStatusRequest) (*GetConsensusStatusResponse, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	// 获取当前共识状态
	status := s.consensusAlgo.GetStatus()
	
	// 获取活跃节点列表
	activeNodes := s.nodeManager.GetActiveNodes()

	return &GetConsensusStatusResponse{
		CurrentRound:    status.CurrentRound,
		ActiveNodes:     len(activeNodes),
		ConsensusState:  status.State,
		LastBlockId:     status.LastBlockId,
		LastUpdateTime:  status.LastUpdateTime,
	}, nil
}

// validateProposer 验证提议者身份
func (s *ConsensusService) validateProposer(proposerId string) error {
	// 检查提议者是否是活跃节点
	if !s.nodeManager.IsActiveNode(proposerId) {
		return ErrInvalidProposer
	}

	// 检查提议者权限
	if !s.consensusAlgo.HasProposerRights(proposerId) {
		return ErrNoProposerRights
	}

	return nil
} 