package service

import (
	"context"

	"github.com/your-org/global-fair-currency/internal/identity/biometric"
	"github.com/your-org/global-fair-currency/internal/identity/blockchain"
	"github.com/your-org/global-fair-currency/internal/identity/verification"
	"github.com/your-org/global-fair-currency/pkg/config"
)

type IdentityService struct {
	biometricValidator  *biometric.Validator
	blockchainIdentity *blockchain.Identity
	verificationService *verification.Service
	config             *config.Config
}

func NewIdentityService(cfg *config.Config) *IdentityService {
	return &IdentityService{
		biometricValidator:  biometric.NewValidator(cfg),
		blockchainIdentity: blockchain.NewIdentity(cfg),
		verificationService: verification.NewService(cfg),
		config:             cfg,
	}
}

// RegisterIdentity 处理身份注册请求
func (s *IdentityService) RegisterIdentity(ctx context.Context, req *RegisterIdentityRequest) (*RegisterIdentityResponse, error) {
	// 1. 生物特征验证
	if err := s.biometricValidator.Validate(req.BiometricData); err != nil {
		return nil, err
	}

	// 2. 创建区块链身份
	identity, err := s.blockchainIdentity.Create(req.UserData)
	if err != nil {
		return nil, err
	}

	// 3. 验证唯一性
	if err := s.verificationService.VerifyUniqueness(identity); err != nil {
		return nil, err
	}

	// 4. 生成初始货币额度
	initialBalance, err := s.calculateInitialBalance(req.UserData)
	if err != nil {
		return nil, err
	}

	return &RegisterIdentityResponse{
		IdentityId: identity.ID,
		Balance:    initialBalance,
	}, nil
}

// VerifyIdentity 处理身份验证请求
func (s *IdentityService) VerifyIdentity(ctx context.Context, req *VerifyIdentityRequest) (*VerifyIdentityResponse, error) {
	// 1. 验证生物特征
	if err := s.biometricValidator.Verify(req.BiometricData, req.IdentityId); err != nil {
		return nil, err
	}

	// 2. 验证区块链身份
	if err := s.blockchainIdentity.Verify(req.IdentityId); err != nil {
		return nil, err
	}

	return &VerifyIdentityResponse{
		Valid: true,
	}, nil
}

// 计算初始货币额度
func (s *IdentityService) calculateInitialBalance(userData *UserData) (uint64, error) {
	// 基于年龄、地区等因素计算初始额度
	// 这里需要实现具体的计算逻辑
	return 1000, nil
} 