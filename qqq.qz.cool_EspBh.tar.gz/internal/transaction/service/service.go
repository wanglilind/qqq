package service

import (
	"context"
	"time"

	"github.com/your-org/global-fair-currency/internal/transaction/create"
	"github.com/your-org/global-fair-currency/internal/transaction/validate"
	"github.com/your-org/global-fair-currency/internal/transaction/history"
	"github.com/your-org/global-fair-currency/pkg/config"
	"github.com/your-org/global-fair-currency/pkg/crypto"
)

type TransactionService struct {
	creator     *create.Service
	validator   *validate.Service
	historian   *history.Service
	config      *config.Config
	cryptoUtils *crypto.Utils
}

func NewTransactionService(cfg *config.Config) *TransactionService {
	return &TransactionService{
		creator:     create.NewService(cfg),
		validator:   validate.NewService(cfg),
		historian:   history.NewService(cfg),
		config:      cfg,
		cryptoUtils: crypto.NewUtils(),
	}
}

// CreateTransaction 处理交易创建请求
func (s *TransactionService) CreateTransaction(ctx context.Context, req *CreateTransactionRequest) (*CreateTransactionResponse, error) {
	// 1. 验证交易请求
	if err := s.validator.ValidateRequest(req); err != nil {
		return nil, err
	}

	// 2. 检查生命周期约束
	if err := s.checkLifecycleConstraints(req.SenderId); err != nil {
		return nil, err
	}

	// 3. 创建交易
	transaction := &Transaction{
		SenderId:    req.SenderId,
		RecipientId: req.RecipientId,
		Amount:      req.Amount,
		Timestamp:   time.Now().Unix(),
		Type:        req.Type,
	}

	// 4. 签名交易
	signature, err := s.cryptoUtils.SignTransaction(transaction)
	if err != nil {
		return nil, err
	}
	transaction.Signature = signature

	// 5. 广播交易
	if err := s.creator.BroadcastTransaction(transaction); err != nil {
		return nil, err
	}

	// 6. 记录历史
	if err := s.historian.RecordTransaction(transaction); err != nil {
		return nil, err
	}

	return &CreateTransactionResponse{
		TransactionId: transaction.Id,
		Status:        "success",
		Timestamp:     transaction.Timestamp,
	}, nil
}

// GetTransactionHistory 获取交易历史
func (s *TransactionService) GetTransactionHistory(ctx context.Context, req *GetTransactionHistoryRequest) (*GetTransactionHistoryResponse, error) {
	// 获取交易历史
	history, err := s.historian.GetHistory(req.UserId, req.StartTime, req.EndTime)
	if err != nil {
		return nil, err
	}

	return &GetTransactionHistoryResponse{
		Transactions: history,
	}, nil
}

// 检查生命周期约束
func (s *TransactionService) checkLifecycleConstraints(userId string) error {
	// 1. 获取用户年龄
	userAge, err := s.getUserAge(userId)
	if err != nil {
		return err
	}

	// 2. 计算剩余生命周期
	remainingLifecycle := 120 - userAge // 120年生命周期

	// 3. 检查交易限制
	if remainingLifecycle <= 0 {
		return ErrLifecycleExpired
	}

	return nil
}

// 获取用户年龄
func (s *TransactionService) getUserAge(userId string) (int, error) {
	// 调用身份服务获取用户信息
	// 这里需要实现具体的调用逻辑
	return 30, nil
} 